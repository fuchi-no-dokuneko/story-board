# StoryBlock v2 fixes — reference mockups

Two self-contained pages show the target behaviour for the problems found when verifying `/?ui=v2`
(main @ 89b72b3). They are built on the same Concept A (desktop) and Concept D (phone) code that
`client-web-v2/src/design` imported, so markup and CSS can be compared directly.

| File | What it shows |
|---|---|
| `v2-fix-desktop.html` | Desktop layout (≥ 761 px) with fixes F1–F5 |
| `v2-fix-mobile.html` | Phone layout (≤ 760 px) with fixes F1–F5 |
| `v2-fix-acceptance.py` | 27 Playwright checks that pass on both mockups; port them to the UAT |

Press **Design notes** (✓ button) in each page for the fix list, file locations in `client-web-v2`,
data mapping and the tests. Review with 末班電車不載影子 (30 chapters, 714 analysis windows) and
末班車之前 (2 windows).

| ID | Fix |
|---|---|
| F1 | Quality windows: chart + stepper + Highest/Lowest instead of one control per window; chapter/paragraph labels; window-filtered evidence; “Show in text” bands the window; phone list collapsed and paged by 50 |
| F2 | Hide empty scene facts (registered novels have none) |
| F3 | Desktop Appearance Auto/Light/Dark following the OS; Page “White” keeps dark text |
| F4 | Readable metric names instead of API ids |
| F5 | English plurals; upright 1–2 digit runs in vertical cover titles |
| F6 | Re-open a book without re-downloading it (not visible; test by request count) |

The “cached until the server restarts” wording applies only if analysis caching (cache brief D6) is approved.
