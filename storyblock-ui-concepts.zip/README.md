# StoryBlock — UI concepts for review

Four clickable HTML mockups for the StoryBlock web library (`server/src/main/resources/static`).
Each file is self-contained: open it in any browser, desktop or phone. Press **Design notes**
(bottom corner) in each file for the rationale, the API endpoints it uses, suggested API
additions and effort. The files link to each other when kept in the same folder.

| File | Concept | Best for |
|---|---|---|
| `concept-a-reader.html` | **A · Reader-first** — bookshelf + calm reader; Style/Quality/Revision in a slide-over drawer | People who mainly read and occasionally analyse |
| `concept-b-workbench.html` | **B · Workbench** — catalog · manuscript (prose / blocks / annotated) · inspector, ⌘K palette, status bar | Operators auditing agent-authored novels block by block |
| `concept-c-insights.html` | **C · Insights dashboard** — each novel as a report: structure strip, cast grid, style heatmap, quality cards | Reviewing style and quality results |
| `concept-d-pocket.html` | **D · Pocket** — phone-first app with bottom tabs and sheets | Phone use; can be the <760 px layout for A or C |

## What today's UI gets wrong (measured with the fixture 《末班車之前》)

- The story text starts ~1,300 px down on desktop and ~2,100 px on a phone, below export buttons, a style table and a quality table.
- Every label is doubled ("Export PDF / 匯出 PDF"); there is no language switch.
- Style distances are raw 6-decimal numbers; the "closest" per column is only bold text.
- Quality evidence is `[start–end] text` with UTF-16 offsets — you cannot see where it is in the story.
- Scene and block metadata (transition, time, place, weather, speaker, POV, narrative mode) is stored but never shown.
- Credentials and the API console sit in the main navigation next to the library.

## Rules every implementation must keep

1. **Read-only library.** No textarea, contenteditable, edit or delete controls (UAT asserts this). The analysis POSTs and PDF render stay.
2. **CSP** `default-src 'none'; script-src 'self'; style-src 'self'` — move inline CSS/JS into static files; system fonts only; no CDN. All charts in the mockups are plain CSS/SVG.
3. **Never combine the five style channels** into one score — rank within a channel only (per `/style-math.html`).
4. **Keep or migrate the UAT selectors** used in `acceptance/features/uat.feature` (`#status-text`, `#reader-title`, `#reader-content`, `.novel-item`, `#chapter-nav .chapter-link`, `#console-tab`, `.quick-requests`, `#response`, …).

## Suggested API additions (optional, noted per concept)

- `block_id` + in-block offsets on each quality evidence item, so "Show in text" is exact.
- `GET /v1/admin/novels/{id}/revisions` for a full revision lineage (Concept C).
- Per-block `present_character_ids` projection for an exact character-presence grid (B, C).
